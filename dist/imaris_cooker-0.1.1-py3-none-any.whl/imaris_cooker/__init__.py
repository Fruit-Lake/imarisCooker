# _*_ coding: utf-8 _*_
# @Author  : Guanhao Sun

from .ims_to_tiff import IMSReader, convert_ims_to_tiff

__version__ = '0.1.0'
__all__ = ['IMSReader', 'convert_ims_to_tiff']